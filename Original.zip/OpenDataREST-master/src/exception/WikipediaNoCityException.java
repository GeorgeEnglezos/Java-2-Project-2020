package exception;

public class WikipediaNoCityException extends Exception {
	private static final long serialVersionUID = 1L;
//Students will implement it.
}
